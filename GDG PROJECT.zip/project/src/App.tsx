import React from 'react';
import { Brain, Microscope, Timer, Database, CloudCog, TrendingUp, FlaskRound as Flask, Award, ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-5xl font-extrabold text-gray-900 sm:text-6xl lg:text-7xl tracking-tight">
              AI-Powered Drug Discovery
              <span className="block text-blue-600">Reimagined</span>
            </h1>
            <p className="mt-6 text-xl text-gray-500 max-w-3xl mx-auto">
              Accelerating pharmaceutical research through advanced machine learning, reducing drug discovery time by 50% while improving success rates.
            </p>
            <div className="mt-10">
              <a href="#contact" className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:text-lg">
                Get Started
                <ChevronRight className="ml-2 h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Features Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Revolutionary Features
            </h2>
            <p className="mt-4 text-lg text-gray-500">
              Cutting-edge technology meets pharmaceutical research
            </p>
          </div>

          <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Brain,
                title: "AI-Powered Generation",
                description: "Generate novel drug molecules using advanced deep learning algorithms"
              },
              {
                icon: Microscope,
                title: "Multi-Target Optimization",
                description: "Optimize drug candidates for multiple therapeutic targets simultaneously"
              },
              {
                icon: Timer,
                title: "Accelerated Discovery",
                description: "Reduce development time by 50% through predictive analytics"
              },
              {
                icon: Database,
                title: "Bioinformatics Integration",
                description: "Seamless integration with leading bioinformatics databases"
              },
              {
                icon: CloudCog,
                title: "Cloud Platform",
                description: "Scalable cloud-based infrastructure for distributed computing"
              },
              {
                icon: TrendingUp,
                title: "Predictive Analytics",
                description: "Advanced property prediction and success rate optimization"
              }
            ].map((feature, index) => (
              <div key={index} className="relative p-8 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                <div className="absolute top-8 left-8">
                  <feature.icon className="h-6 w-6 text-blue-600" />
                </div>
                <div className="mt-8">
                  <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
                  <p className="mt-4 text-gray-500">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-blue-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { number: "50%", label: "Reduced Development Time" },
              { number: "90%", label: "Cost Reduction" },
              { number: "2x", label: "Success Rate Increase" },
              { number: "24/7", label: "Automated Analysis" }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <p className="text-5xl font-extrabold text-white">{stat.number}</p>
                <p className="mt-2 text-xl text-blue-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900">
              Powered by Advanced Technology
            </h2>
            <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-3 lg:grid-cols-6">
              {[
                "Python",
                "TensorFlow",
                "PyTorch",
                "RDKit",
                "DeepChem",
                "FastAPI"
              ].map((tech, index) => (
                <div key={index} className="flex items-center justify-center p-6 bg-gray-50 rounded-lg">
                  <Flask className="h-8 w-8 text-blue-600 mr-2" />
                  <span className="font-medium text-gray-900">{tech}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Awards Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900">
              Recognition & Achievements
            </h2>
            <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {[
                {
                  title: "Innovation Award",
                  description: "Recognized for breakthrough AI technology in drug discovery"
                },
                {
                  title: "Research Excellence",
                  description: "Leading publication in computational chemistry"
                },
                {
                  title: "Industry Impact",
                  description: "Transforming pharmaceutical research methodology"
                }
              ].map((award, index) => (
                <div key={index} className="p-8 bg-white rounded-xl shadow-sm">
                  <Award className="h-12 w-12 text-blue-600 mx-auto" />
                  <h3 className="mt-6 text-xl font-semibold text-gray-900">{award.title}</h3>
                  <p className="mt-4 text-gray-500">{award.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-lg">Revolutionizing Drug Discovery Through AI</p>
            <p className="mt-4 text-gray-400">© 2025 AI Drug Discovery Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;